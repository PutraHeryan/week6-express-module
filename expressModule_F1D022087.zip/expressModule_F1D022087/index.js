const express = require('express');
const { tambah } = require('./utils/math.js');
const profileRouter = require('./routes/profile.js');

const app = express();
const port = 3000;

app.get('/', (req, res) => {
  res.send('Putra Heryan Gagah Perkasa_F1D022087');
});

app.get('/hitung', (req, res) => {
  const hasil = tambah(20, 30);
  res.send(`Hasil penjumlahan 20 + 30 adalah ${hasil}`);
});

app.use('/profile', profileRouter);

app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});
