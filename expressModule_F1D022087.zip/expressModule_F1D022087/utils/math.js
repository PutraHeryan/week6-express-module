const tambah = (a, b) => {
  return a + b;
};

const kali = (a, b) => {
  return a * b;
};

module.exports = {
  tambah,
  kali
};