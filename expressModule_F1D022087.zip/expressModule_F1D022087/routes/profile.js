const express = require('express');
const router = express.Router();

const profiles = [
  {
    nim: "F1D022087",
    nama: "Putra Heryan Gagah Perkasa",
    prodi: "Informatika",
    fakultas: "Teknik"
  },
  {
    nim: "F1D022142",
    nama: "Muhammad Daffa Dzaki Ahnaf",
    prodi: "Informatika",
    fakultas: "Teknik"
  },
  {
    nim: "F1D022035",
    nama: "Apta Mahogra Bhamakerti",
    prodi: "Informatika",
    fakultas: "Teknik"
  }
];

router.get('/', (req, res) => {
  res.json(profiles);
});

router.get('/:nim', (req, res) => {
  const nimCari = req.params.nim;
  
  const profile = profiles.find(p => p.nim === nimCari);
  
  if (profile) {
    res.json(profile);
  } else {
    res.status(404).send('Profile dengan NIM tersebut tidak ditemukan.');
  }
});

module.exports = router;
